#include<stdio.h>

int main()
{
    int x, y, sum;
    printf("Input the first integer: \n");
    scanf("%d", &x);
    printf("Input the second integer: \n");
    scanf("%d", &y);
    sum = x + y;
    printf("\nsum of the above two integer = %d\n", sum);
    return 0;
}