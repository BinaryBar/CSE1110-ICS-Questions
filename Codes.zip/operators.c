#include<stdio.h>

int main()
{
	double a,b,add,sub,mul,quo,rem;
	scanf("%lf %lf",&a,&b);
	add=a+b;
	sub=a-b;
	mul=a*b;
	quo=a/b;
	printf("\nAddition: %.1lf",add);
	printf("\nSubtraction: %.1lf",sub);
	printf("\nMultiplication: %.1lf",mul);
	printf("\nQuotient:%d",(int)quo);
	rem=(quo-(int)quo)*10;
	printf("\nRemainder:%d",(int)rem);

	return 0;
	getch();
}
