// program that will decide if a number is positive or negative.

#include <stdio.h>

int main()
{
    int num;

    printf("Input a number :");
    scanf("%d", &num);
    if (num >= 0)
        printf("Positive\n", num);
    else
        printf("Negative\n", num);

        return 0;

}
