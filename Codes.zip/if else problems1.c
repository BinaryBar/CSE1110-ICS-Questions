#include<stdio.h>

int main()
{
    int day = 5;

     switch (day); {
      case 1:
       printf("Saturday");
       break;

      case 2:
       printf("Sunday");
       break;

      case 3:
       printf("Monday");
       break;

      case
       printf("Tuesday");
       break;

      case 5:
       printf("Wednesday");
       break;

      case 6:
       printf("Thursday");
       break;

      case 7:
       printf("Friday");
       break;

    }
   return 0;
}

