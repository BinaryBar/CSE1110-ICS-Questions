#include<stdio.h>

int main()
{
    int r;
   float PI = 3.14, area,ci;

   printf("\nEnter radius of circle: ");
   scanf("%d", &r);

   ci = 2 * PI * r;
   printf("\nCircumference : %.2f ", ci);

   return 0;
}

