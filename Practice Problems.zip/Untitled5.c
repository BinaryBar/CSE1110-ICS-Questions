#include <stdio.h>

int main()
{
    int a;
    scanf("%d", &a);
    printf("The integer value: %d\n", a);

    return 0;
}
