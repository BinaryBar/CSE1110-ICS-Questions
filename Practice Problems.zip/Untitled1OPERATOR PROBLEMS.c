#include<stdio.h>

int main()
{
    int X,Y,addition,subtraction,multiplication,division,modulus;
    float quotient;
    printf("Enter the First number: ");
    scanf("%d",&X);
    printf("Enter the second number: ");
    scanf("%d",&Y);
    addition = X + Y;
    subtraction = X - Y;
    multiplication = X * Y;
    division = X / Y;
    modulus = X % Y;

    printf("\naddition = %d", addition);
    printf("\nsubtraction  = %d", subtraction);
    printf("\nmultiplication = %d", multiplication);
    printf("\ndivision = %d", division);
    printf("\nmodulus = %d", modulus);

    getch();
    return 0;
}
