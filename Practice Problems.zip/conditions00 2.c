// Program that will decide whether a number is even or odd.


#include <stdio.h>

int main() {
    int num;
    printf("Enter an integer: ");
    scanf("%d", &num);

    // true if number is perfectly divisible by 2

    if(num % 2 == 0)
        printf("Even.", num);
    else
        printf("Odd.", num);

        return 0;
}
