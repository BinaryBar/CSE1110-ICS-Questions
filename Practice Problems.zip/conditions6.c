#include<stdio.h>

int main()
{
   int num;

   printf("Enter the number: ");
   scanf("%d", &num);

   if (checkPowerofTwo(num) == 1)
      printf("\n%d is a power of 2\n", num);
   else
      printf("\n%d is not a power of 2\n", num);

   return 0;
}
