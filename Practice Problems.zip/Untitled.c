#include <stdio.h>

int main()
{
    int Firstvalue = 20;
    int Middlevalue = 50;
    int Lastvalue = 100;


    printf("First value = %d ", Firstvalue);

    printf("%n", Middlevalue);

    printf("Last value = %d", Lastvalue);

    return 0;
}
