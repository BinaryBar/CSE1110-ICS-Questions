// write a program that will print following series upto N term.

#include<stdio.h>

int main()
{
    int i,n,series=2;
    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        printf("%d ", series);
        series=series+2;
    }
    return 0;
}
