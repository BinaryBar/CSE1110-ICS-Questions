#include <stdio.h>

int main()
{
    printf("The question is- \"How to write a\n");
    printf("comment in C programming language.\"");
    // This is a comment

    return 0;
}

