#include <stdio.h>

int main()
{
    printf("Hello world.\n");
    printf("This is my first C program.    C is fun.");

    return 0;
}
