#include <stdio.h>

int main()
{
    int a;
    float b;
    char 'a' ;

    scanf("%d", &a);
    printf("The integer value: %d\n", a);
    scanf("%f", &b);
    printf("The floating point value: %f\n", b);
    scanf("%c", &a);
    printf("The character value: %c\n", c);

    return 0;
}
